<?php
defined('BASEPATH') or exit ('No direct script acess allowed');

include_once("M_Usuario.php");
class M_Ticket extends CI_model {
    
    public function inserirTicket($codigo_usuario, $descricao, $progresso){
        $retornoToken = $this->consultarSoTicket($codigo_usuario);

        if ($retornoToken['codigo'] == 2){

            $sql = "insert into ticket (codigo_usuario, descricao, progresso)
                    values ('$codigo_usuario','$descricao','$progresso')";

                    $this->db->query($sql);

            if($this->db->affected_rows() > 0){
                $dados = array('codigo' => 1,
                               'msg'    => 'Ticket cadastrado corretamente.');

            }else {
                $dados = array('codigo' => 4,
                               'msg'    => 'Codigo do Ticket não informado');                   
            
            }
        }else {
            $dados = array('codigo' => 4,
                           'msg'    => 'Ticket ja se encontra na base de dados.');                          
      
        }
        return $dados;

}
    

        public function consultarTicket($codigo_usuario, $codigo_ticket, $descricao, $solucao, $progresso){

            $sql = "select * from ticket
                    where codigo_ticket = '$codigo_ticket' ";
    
    
            
             if($codigo_usuario != ''){
                 $sql = $sql . "and codigo_usuario = '$codigo_usuario' ";
             }
                        
        
            if($descricao != ''){
                $sql = $sql . "and descricao = '$descricao' ";
            }

            if($solucao != ''){
                $sql = $sql . "and solucao = '$solucao' ";
            }

            if($progresso != ''){
                $sql = $sql . "and progresso = '$progresso' ";
            }
    
        
            $retorno = $this->db->query($sql);
        
            if($retorno->num_rows() > 0){
                $dados = array('codigo' => 1,
                               'msg'    => 'Consulta efetuada com sucesso.',
                               'dados' => $retorno->result());
            }else{
                $dados = array('codigo' => 2,
                               'msg'    => 'Dados nao encontrados.');
            }
        
            return $dados;
        }

        private function consultarSoTicket($codigo_usuario)
    {
        $sql = "select * from ticket where codigo_usuario = '$codigo_usuario'";

        $retorno = $this->db->query($sql);

        if ($retorno->num_rows() > 0) {
            $dados = array(
                'codigo' => 1,
                'msg'    => 'Consulta efetuada com sucesso.'
            );
        } else {
            $dados = array(
                'codigo' => 2,
                'msg'    => 'Dados não encontrados.'
            );
        }

        return $dados;
    }

    public function alterarTicket($codigo_usuario, $codigo_ticket, $progresso, $solucao, $descricao)
    {

        $retorno = $this->consultarSoTicket($codigo_usuario);

        if ($retorno['codigo'] == 1) {
            $sql = "update ticket set progresso = '$progresso',
                    solucao = '$solucao',
                    descricao = '$descricao'
                    where codigo_ticket = '$codigo_ticket'";

            $this->db->query($sql);

            if ($this->db->affected_rows() > 0) {
                $dados = array(
                    'codigo' => 1,
                    'msg'    => 'Dados do token atualizados corretamente.'
                );
            } else {
                $dados = array(
                    'codigo' => 2,
                    'msg'    => 'Houve algum problema na atualização do token.'
                );
            }
        } else {
            $dados = array(
                'codigo' => 5,
                'msg'    => 'O Codigo do token nao foi encontrado na base de dados.'
            );
        }
        return $dados;
    }
    }
