<?php
defined('BASEPATH') or exit('No direct script acess allowed');

include_once("M_Usuario.php");
class M_Token extends CI_model
{

    public function inserirToken($codigo_usuario, $numero_token)
    {
        $retornoToken = $this->consultarSoToken($numero_token);

        if ($retornoToken['codigo'] == 2) {

            $sql = "insert into token (codigo_usuario, numero_token)
                    values ('$codigo_usuario','$numero_token')";

            $this->db->query($sql);

            if ($this->db->affected_rows() > 0) {
                $dados = array(
                    'codigo' => 1,
                    'msg'    => 'Token cadastrado corretamente.'
                );
            } else {
                $dados = array(
                    'codigo' => 2,
                    'msg'    => 'Houve algum problema na insercao na tabela de Token'
                );
            }
        } else {
            $dados = array(
                'codigo' => 8,
                'msg'    => 'Token ja se encontra cadastrado na base de dados.'
            );
        }

        return $dados;
    }


    public function consultarToken($codigo_usuario, $numero_token)
    {

        $sql = "select * from token
                where numero_token = '$numero_token' ";



        if ($codigo_usuario != '') {
            $sql = $sql . "and codigo_usuario = '$codigo_usuario' ";
        }


        if ($numero_token != '') {
            $sql = $sql . "and numero_token = '$numero_token' ";
        }


        $retorno = $this->db->query($sql);

        if ($retorno->num_rows() > 0) {
            $dados = array(
                'codigo' => 1,
                'msg'    => 'Consulta efetuada com sucesso.',
                'dados' => $retorno->result()
            );
        } else {
            $dados = array(
                'codigo' => 2,
                'msg'    => 'Dados nao encontrados.'
            );
        }

        return $dados;
    }

    private function consultarSoToken($codigo_usuario)
    {
        $sql = "select * from token where codigo_usuario = '$codigo_usuario'";

        $retorno = $this->db->query($sql);

        if ($retorno->num_rows() > 0) {
            $dados = array(
                'codigo' => 1,
                'msg'    => 'Consulta efetuada com sucesso.'
            );
        } else {
            $dados = array(
                'codigo' => 2,
                'msg'    => 'Dados não encontrados.'
            );
        }

        return $dados;
    }


    public function alterarToken($codigo_usuario, $numero_token)
    {

        $retorno = $this->consultarSoToken($codigo_usuario);

        if ($retorno['codigo'] == 1) {
            $sql = "update token set numero_token = '$numero_token'
                    where codigo_usuario = '$codigo_usuario'";

            $this->db->query($sql);

            if ($this->db->affected_rows() > 0) {
                $dados = array(
                    'codigo' => 1,
                    'msg'    => 'Dados do token atualizados corretamente.'
                );
            } else {
                $dados = array(
                    'codigo' => 2,
                    'msg'    => 'Houve algum problema na atualização do token.'
                );
            }
        } else {
            $dados = array(
                'codigo' => 5,
                'msg'    => 'O Codigo do token nao foi encontrado na base de dados.'
            );
        }
        return $dados;
    }
}


//CODIGO 1 - DADOS CORRETOS 
//CODIGO 2 - CAMPO NAO INSERIDO
//CODIGO 3 - USUARIO NAO BATE NA BASE DA DADOS
//CODIGO 4 - SENHA NAO BATE NA BASE DE DADOS