<?php
defined('BASEPATH') or exit('No direct script access allowed');

class M_Acesso extends CI_Model
{
    public function inserirAcesso($codigo_usuario)
    {
        $retornoUsuario = $this->consultarUsuario($codigo_usuario);
        
        if ($retornoUsuario['codigo'] == 1) {

            $tipoPorta = $this->verificarAcesso($codigo_usuario);
            // Use parameterized query to prevent SQL injection
            $data = array(
                'codigo_usuario' => $codigo_usuario,
                'datas_hora' => date('Y-m-d H:i:s'),
                'open_close' => $tipoPorta['codigo']
            );            

            if ($this->db->insert('acesso', $data)) {
                // Optionally retrieve the last inserted ID or return a success message
                return array('codigo' => 1, 'msg' => $tipoPorta['msg']);
            } else {
                return array('codigo' => 3, 'msg' => 'Erro ao inserir acesso.');
            }
        }
        return $retornoUsuario; // Return the user check result
    }

    private function verificarAcesso($codigo_usuario){
        $sql = "select * from acesso 
                where codigo_usuario = $codigo_usuario
                and datas_hora = (select max(datas_hora) 
                                  from acesso 
                                  where codigo_usuario = $codigo_usuario);";

        $retorno = $this->db->query($sql);

        if ($retorno->num_rows() > 0) {
            $linha = $retorno->row();

            if($linha->open_close == 0){
                $tipo = 1;
                $msg = "Acesso liberado";
            }else{
                $tipo = 0;
                $msg = "Acesso fechado";
            }

            $dados = array(
                'codigo' => $tipo,
                'msg' => $msg
            );
        } else {
            $dados = array(
                'codigo' => 3,
                'msg'    => 'Usuario não possui acesso.'
            );
        }
        return $dados;
    }

    public function consultarUsuario($codigo)
    {
        $this->db->where('codigo_usuario', $codigo);
        $retorno = $this->db->get('usuario');

        if ($retorno->num_rows() > 0) {
            return array('codigo' => 1, 'msg' => 'Consulta efetuada com sucesso.', 'dados' => $retorno->result());
        } else {
            return array('codigo' => 2, 'msg' => 'Dados não encontrados.');
        }
    }
}