<?php
defined('BASEPATH') or exit ('No direct script acess allowed');

include_once("M_Token.php");

class M_Usuario extends CI_model {
    public function inserirUsuario($nome, $senha, $cargo, $email, $codigo_usuario){
        $retornoUsuario = $this->consultarUsuario($nome, $senha, $cargo, $email, $codigo_usuario);

        if ($retornoUsuario['codigo'] == 2){

            $sql = "insert into usuario (nome, senha, cargo, email)
                    values ('$nome',md5('$senha'),'$cargo', '$email')";

                    $this->db->query($sql);

            if($this->db->affected_rows() > 0){
                $dados = array('codigo' => 1,
                               'msg'    => 'Usuario cadastrado corretamente.');

            
            }else{
                $dados = array('codigo' => 2,
                               'msg'    => 'Houve algum problema na insercao na tabela de Usuario');                   
            }
        }else{
            $dados = array('codigo' => 8,
                           'msg'    => 'Usuario ja se encontra cadastrado na base de dados.');                          
        }
    
        return $dados;

    }

    public function consultarUsuario($nome, $senha, $cargo, $email){

        $sql = "select * from usuario
                where nome = '$nome' ";
    
        if($senha != ''){
            $sql = $sql . "and senha = '$senha' ";
        }

        if($cargo != ''){
            $sql = $sql . "and cargo = '$cargo' ";
        }

        if($email != ''){
            $sql = $sql . "and email = '$email' ";
        }
    
        if($nome != ''){
            $sql = $sql . "and nome like '$nome' ";
    }
    
        $retorno = $this->db->query($sql);
    
        if($retorno->num_rows() > 0){
            $dados = array('codigo' => 1,
                           'msg'    => 'Consulta efetuada com sucesso.',
                           'dados' => $retorno->result());
        }else{
            $dados = array('codigo' => 2,
                           'msg'    => 'Dados nao encontrados.');
        }
    
        return $dados;
        
    }

    public function consultarSoUsuario($codigo_usuario){

        $sql = "select * from usuario
                where codigo_usuario = '$codigo_usuario'";

        $retorno = $this->db->query($sql);

        if($retorno->num_rows() > 0){
            $dados = array ('codigo' => 1,
                            'msg'    => 'Consulta efetuada com sucesso.');

        }else{
            $dados = array('codigo' => 0,
                           'msg'    => 'Dados nao encontrados.');
        }

        return $dados;
    }

    

    public function alterarUsuario($nome, $senha, $email, $codigo_usuario){
        
        $retornoUsuario = $this->consultarSoUsuario($codigo_usuario);

        if ($retornoUsuario['codigo'] == 1){

            $sql = "update usuario set nome = '$nome', senha = '$senha', email = '$email' 
            where codigo_usuario = '$codigo_usuario'";

            $this->db->query($sql);

            if($this->db->affected_rows() > 0){
                $dados = array ('codigo' => 1,
                                'msg'    => 'Dados do usuario atualizados corretamente.');

            }else{
                $dados = array('codigo' => 5,
                               'msg'    => 'Erro na atualização dos dados');                           
            }
            
        }else{
            $dados = array('codigo' => 3,
                           'msg'    => 'O codigo do usuario passado nao esta cadastrado na base de dados.');

        }

        return $dados;
    
    }

    public function apagarUsuario($codigo_usuario){
        $retornoUsuario = $this->consultarSoUsuario($codigo_usuario);

        if ($retornoUsuario['codigo'] == 1){
            $sql = "update usuario set estatus = 'D'
                    where codigo_usuario = $codigo_usuario";

            $this->db->query($sql);

            if($this->db->affected_rows() > 0){
                $dados = array('codigo' => 1,
                               'msg'    =>'Usuario desativado corretamente.');

            }else{
                $dados = array('codigo' => 2,
                               'msg'    =>'Houve algum problema na desativação do Usuario.');
            }

        }else{
            $dados = array('codigo' => 4,
                           'msg'    =>'O Usuario informado não esta cadastrado na base de dados.');
        }

        return $dados;
    }


}

//CODIGO 1 - DADOS CORRETOS 
//CODIGO 2 - CAMPO NAO INSERIDO
//CODIGO 3 - USUARIO NAO BATE NA BASE DA DADOS
//CODIGO 4 - SENHA NAO BATE NA BASE DE DADOS
//CODIGO 5 - ERRO NA FUNÇAÔ

