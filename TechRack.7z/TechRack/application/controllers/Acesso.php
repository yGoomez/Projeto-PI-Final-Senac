<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Acesso extends CI_Controller
{
    private $codigo_usuario;

    public function getCodigo_usuario()
    {
        return $this->codigo_usuario;
    }

    public function setCodigo_usuario($codigo_usuarioFront)
    {
        $this->codigo_usuario = $codigo_usuarioFront;
    }

    public function inserirAcesso()
    {
        $json = file_get_contents('php://input');
        $resultado = json_decode($json);

        $lista = array("codigo_usuario" => '0');

        if (verificarParam($resultado, $lista) == 1) {
            $this->setCodigo_usuario($resultado->codigo_usuario);
        }

        if (trim($this->getCodigo_usuario()) == "" || $this->getCodigo_usuario() == 0) {
            $retorno = array(
                'codigo' => 4,
                'msg'    => 'Código do Usuário não informado.'
            );
        } else {
            $this->load->model('M_Acesso');
            $retorno = $this->M_Acesso->inserirAcesso($this->getCodigo_usuario());
        }

        // Return response as JSON
        header('Content-Type: application/json');
        echo json_encode($retorno);
    }
}