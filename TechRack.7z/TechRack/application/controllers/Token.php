<?php

defined('BASEPATH') or exit('No direct script acess allowed');


class Token extends CI_Controller
{

    private $json;
    private $codigo_usuario;

    private $codigo_token;
    private $numero_token;
    private $estatus_token;

    public function getCodigo_usuario()
    {
        return $this->codigo_usuario;
    }

    public function getCodigo_token()
    {
        return $this->codigo_token;
    }

    public function getNumero_token()
    {
        return $this->numero_token;
    }

    public function getEstatus_token()
    {
        return $this->estatus_token;
    }

    public function setCodigo_usuario($codigo_usuarioFront)
    {
        $this->codigo_usuario = $codigo_usuarioFront;
    }

    public function setCodigo_token($codigo_tokenFront)
    {
        $this->codigo_token = $codigo_tokenFront;
    }

    public function setNumero_token($numero_tokenFront)
    {
        $this->numero_token = $numero_tokenFront;
    }

    public function setEstatus_token($estatus_tokenFront)
    {
        $this->estatus_token = $estatus_tokenFront;
    }

    public function inserirToken()
    {
        $json = file_get_contents('php://input');
        $resultado = json_decode($json);

        $lista = array(
            "codigo_usuario" => '0',
            "numero_token" => '0'
        );

        if (verificarParam($resultado, $lista) == 1) {

            $this->setCodigo_usuario($resultado->codigo_usuario);
            $this->setNumero_token($resultado->numero_token);

            if (trim($this->getCodigo_usuario()) == "" || $this->getCodigo_usuario() == 0) {
                $retorno = array(
                    'codigo' => 4,
                    'msg'    => 'Código do Usuario não informado.'
                );
            } elseif (trim($this->getNumero_token()) == "" || $this->getNumero_token() == 0) {
                $retorno = array(
                    'codigo' => 4,
                    'msg'    => 'Numero do Token não informado.'
                );
            } else {

                $this->load->model('M_Token');

                $retorno = $this->M_Token->inserirToken(
                    $this->getCodigo_usuario(),
                    $this->getNumero_token(),
                    $this->getCodigo_token()
                );
            }

            echo json_encode($retorno);
        }
    }


    public function consultarToken()
    {

        $json = file_get_contents('php://input');
        $resultado = json_decode($json);

        $lista = array(
            "codigo_usuario" => '0',
            "numero_token" => '0'
        );

        if (verificarParam($resultado, $lista) == 1) {
        }
        $this->setCodigo_usuario($resultado->codigo_usuario);
        $this->setNumero_token($resultado->numero_token);

        if (trim($this->getCodigo_usuario()) == "" || $this->getCodigo_usuario() == 0) {
            $retorno = array(
                'codigo' => 4,
                'msg'    => 'Código do Usuario não informado.'
            );
        } elseif (trim($this->getNumero_token()) == "" || $this->getNumero_token() == 0) {
            $retorno = array(
                'codigo' => 4,
                'msg'    => 'Numero do Token não informado.'
            );
        } else {

            $this->load->model('M_Token');

            $retorno = $this->M_Token->consultarToken(
                $this->getCodigo_usuario(),
                $this->getNumero_token()
            );
        }

        echo json_encode($retorno);
    }


    public function alterarToken()
    {

        $json = file_get_contents('php://input');
        $resultado = json_decode($json);

        $lista = array(
            "numero_token" => '0',
            "codigo_usuario" => '0'
        );

        if (verificarParam($resultado, $lista) == 0) {
            echo json_encode(['codigo' => 4, 'msg' => 'Parâmetros inválidos.']);
            return;
        }

        $this->setNumero_token($resultado->numero_token);
        $this->setCodigo_usuario($resultado->codigo_usuario);

        if (empty($this->getNumero_token())) {
            echo json_encode(['codigo' => 4, 'msg' => 'Numero do Token não informado.']);
            return;
        }

        if (empty($this->getCodigo_usuario())) {
            echo json_encode(['codigo' => 4, 'msg' => 'Código do Usuario não informado.']);
            return;
        }

        $this->load->model('M_Token');
        $retorno = $this->M_Token->alterarToken($this->getCodigo_usuario(), $this->getNumero_token());

        echo json_encode($retorno);
    }
}
