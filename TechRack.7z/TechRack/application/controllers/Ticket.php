<?php

defined('BASEPATH') or exit('No direct script acess allowed');


class Ticket extends CI_Controller
{

    private $json;
    private $codigo_usuario;

    private $codigo_ticket;
    private $descricao;

    private $progresso;

    private $solucao;
    private $estatus_ticket;

    public function getCodigo_usuario()
    {
        return $this->codigo_usuario;
    }

    public function getCodigo_ticket()
    {
        return $this->codigo_ticket;
    }

    public function getDescricao()
    {
        return $this->descricao;
    }

    public function getProgresso()
    {
        return $this->progresso;
    }

    public function getSolucao()
    {
        return $this->solucao;
    }


    public function getEstatus_ticket()
    {
        return $this->estatus_ticket;
    }

    public function setCodigo_usuario($codigo_usuarioFront)
    {
        $this->codigo_usuario = $codigo_usuarioFront;
    }

    public function setCodigo_ticket($codigo_ticketFront)
    {
        $this->codigo_ticket = $codigo_ticketFront;
    }

    public function setDescricao($descricaoFront)
    {
        $this->descricao = $descricaoFront;
    }

    public function setProgresso($progressoFront)
    {
        $this->progresso = $progressoFront;
    }

    public function setSolucao($solucaoFront)
    {
        $this->solucao = $solucaoFront;
    }

    public function inserirTicket()
    {
        $json = file_get_contents('php://input');
        $resultado = json_decode($json);

        $lista = array(
            "codigo_usuario" => '0',
            "descricao" => '0',
            "progresso" => '0',
        );

        if (verificarParam($resultado, $lista) == 1) {

            $this->setCodigo_usuario($resultado->codigo_usuario);
            $this->setDescricao($resultado->descricao);
            $this->setProgresso($resultado->progresso);
        }

        if (trim($this->getCodigo_usuario()) == "" || $this->getCodigo_usuario() == 0) {
            $retorno = array(
                'codigo' => 4,
                'msg'    => 'Código do Usuario não informado.'
            );
        } elseif (trim($this->getDescricao()) == "" || $this->getDescricao() == 0) {
            $retorno = array(
                'codigo' => 4,
                'msg'    => 'Descrição não informada.'
            );
        } elseif (trim($this->getProgresso()) == "" || $this->getProgresso() == 0) {
            $retorno = array(
                'codigo' => 4,
                'msg'    => 'Progresso não informado.'
            );
        } else {

            $this->load->model('M_Ticket');

            $retorno = $this->M_Ticket->inserirTicket(
                $this->getCodigo_usuario(),
                $this->getDescricao(),
                $this->getProgresso()
            );
        }

        echo json_encode($retorno);
    }

    public function consultarTicket()
    {

        $json = file_get_contents('php://input');
        $resultado = json_decode($json);

        $lista = array(
            "codigo_ticket" => '0',
            "progresso" => '0',
        );

        if (verificarParam($resultado, $lista) == 1) {

            $this->setCodigo_ticket($resultado->codigo_ticket);
            $this->setProgresso($resultado->progresso);

            if (trim($this->getCodigo_ticket()) == "" || $this->getCodigo_ticket() == 0) {
                $retorno = array(
                    'codigo' => 4,
                    'msg'    => 'Código do Ticket não informado.'
                );
            } elseif (trim($this->getProgresso()) == "" || $this->getProgresso() == 0) {
                $retorno = array(
                    'codigo' => 4,
                    'msg'    => 'Progresso não informado.'
                );
            } else {

                $this->load->model('M_Ticket');

                $retorno = $this->M_Ticket->consultarTicket(
                    $this->getCodigo_usuario(),
                    $this->getCodigo_ticket(),
                    $this->getDescricao(),
                    $this->getSolucao(),
                    $this->getProgresso()
                );
            }

            echo json_encode($retorno);
        }
    }

    public function alterarTicket()
    {

        $json = file_get_contents('php://input');
        $resultado = json_decode($json);

        $lista = array(
            "codigo_usuario" => '0',
            "codigo_ticket" => '0',
            "progresso" => '0',
            "solucao" => '0',
            "descricao" => '0'
        );

        if (verificarParam($resultado, $lista) == 1) {

            $this->setCodigo_usuario($resultado->codigo_usuario);
            $this->setCodigo_ticket($resultado->codigo_ticket);
            $this->setProgresso($resultado->progresso);
            $this->setSolucao($resultado->solucao);
            $this->setDescricao($resultado->descricao);

            if ($this->getCodigo_usuario() == "" || $this->getCodigo_usuario() == 0) {
                $retorno = array(
                    'codigo' => 4,
                    'msg'    => 'Código do Usuario não informado.'
                );
            }
            elseif ($this->getCodigo_ticket() == "" || $this->getCodigo_ticket() == 0) {
                $retorno = array(
                    'codigo' => 4,
                    'msg'    => 'Código do Ticket não informado.'
                );
            }
            elseif ($this->getProgresso() == "" || $this->getProgresso() == 0) {
                $retorno = array(
                    'codigo' => 4,
                    'msg'    => 'Progresso não informado.'
                );
            }
            elseif (trim($this->getSolucao()) == "" || $this->getSolucao() == 0) {
                $retorno = array(
                    'codigo' => 4,
                    'msg'    => 'Solução não informada.'
                );
            }
            elseif (trim($this->getDescricao()) == "" || $this->getDescricao() == 0) {
                $retorno = array(
                    'codigo' => 4,
                    'msg'    => 'Descrição não informada.'
                );
            } else {

                $this->load->model('M_Ticket');
                $retorno = $this->M_Ticket->alterarTicket(
                    $this->getCodigo_usuario(),
                    $this->getCodigo_ticket(),
                    $this->getProgresso(),
                    $this->getSolucao(),
                    $this->getDescricao()
                );
            }

            echo json_encode($retorno);
        }
    }
}
