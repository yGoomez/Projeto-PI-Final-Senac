<?php

defined('BASEPATH') OR exit('No direct script acess allowed');


class Usuario extends CI_Controller{

    private $json;
    private $codigo_usuario;
   
    private $nome;
    private $cargo;
    private $email;
    private $senha;
    private $numero_token;

    private $estatus;

    public function getCodigo_usuario(){
        return $this ->codigo_usuario;
    }

    public function getNome(){
        return $this ->nome;
    }

    public function getCargo(){
        return $this ->cargo;
    }

    public function getEmail(){
        return $this ->email;
    }

    public function getSenha(){
        return $this ->senha;
    }

    public function getNumero_Token(){
        return $this ->numero_token;
    }

    public function getEstatus(){
        return $this ->estatus;
    }

    public function setCodigo_usuario($codigo_usuarioFront){
        $this ->codigo_usuario = $codigo_usuarioFront;
    }

    public function setNome($nomeFront){
        $this ->nome = $nomeFront;
    }

    public function setCargo($cargoFront){
        $this ->cargo = $cargoFront;
    }

    public function setEmail($emailFront){
        $this ->email = $emailFront;
    }

    public function setSenha($senhaFront){
        $this ->senha = $senhaFront;
    }
    
    public function setNumero_Token($numero_tokenFront){
        $this ->token = $numero_tokenFront;
    }

    public function setEstatus($estatusFront){
        $this ->estatus = $estatusFront;
    }

    public function inserirUsuario() {
        $json = file_get_contents('php://input');
        $resultado = json_decode($json);

        $lista = array("senha" => '0',
                       "nome"  => '0',
                       "cargo" => '0',
                       "email" => '0');

        if (verificarParam($resultado, $lista) == 1){

            $this->setSenha($resultado->senha);
            $this->setNome($resultado->nome);
            $this->setCargo($resultado->cargo);
            $this->setEmail($resultado->email);
            

            if (trim($this->getNome()) == "" || $this->getNome() == 0){
                $retorno = array('codigo' => 4,
                                 'msg'    => 'Nome do Usuario não informado.');

            }elseif (trim($this->getSenha()) == ""){
                $retorno = array('codigo' => 4,
                                 'msg'    => 'Senha do Usuario não informado.');
                                
            }elseif (trim($this->getCargo()) == "" || $this->getCargo() == 0){
                $retorno = array('codigo' => 4,
                                 'msg'    => 'Cargo do Usuario não informado.');

            }elseif (trim($this->getEmail()) == "" || $this->getEmail() == 0){
                $retorno = array('codigo' => 4,
                                 'msg'    => 'Email do Usuario não informado.');
            }else{
                
                $this->load->model('M_Usuario');

                $retorno = $this->M_Usuario->inserirUsuario($this->getNome(),$this->getSenha(),
                           $this->getCargo(), $this->getEmail(), $this->getCodigo_usuario());

            }
        
            
            echo json_encode($retorno);
        
        }
    }

    public function consultarUsuario(){

        $json = file_get_contents('php://input');
        $resultado = json_decode($json);

        $lista = array(
                       "senha" => '0',
                       "nome"  => '0',
                       "cargo" => '0',
                       "email" => '0');

        if (verificarParam($resultado, $lista) == 1){

            $this->setSenha($resultado->senha);
            $this->setNome($resultado->nome);
            $this->setCargo($resultado->cargo);
            $this->setEmail($resultado->email);
            

            if(trim($this->getNome()) == "" || $this->getNome() == 0){
                $retorno = array('codigo' => 4,
                                 'msg'    => 'codigo do Usuario não informado.');
                
            }else{
                
                $this->load->model('M_Usuario');

                $retorno = $this->M_Usuario->consultarUsuario($this->getNome(),$this->getSenha(),
                           $this->getCargo(), $this->getEmail());

            }
                echo json_encode($retorno);
        }
    }


    public function alterarUsuario() {
        $json = file_get_contents('php://input');
        $resultado = json_decode($json);
        
        $lista = array(
                       "senha" => '0',
                       "nome" => '0', 
                       "email" => '0',
                       "codigo_usuario" => '0');
 
        
        if (verificarParam($resultado, $lista) == 0) {
            echo json_encode(['codigo' => 4, 'msg' => 'Parâmetros inválidos.']);
            return;
        }
        $this->setNome($resultado->nome);
        $this->setSenha(md5($resultado->senha));
        $this->setEmail($resultado->email);
        $this->setCodigo_usuario($resultado->codigo_usuario);
        
        if (empty($this->getNome())) {
            echo json_encode(['codigo' => 4, 'msg' => 'Nome do usuário não informado.']);
            return;
        }

        if (empty($this->getSenha())) {
            echo json_encode(['codigo' => 4, 'msg' => 'Senha não informada.']);
            return;
        }

        
        if (trim($this->getEmail()) == "") {
            echo json_encode(['codigo' => 4, 'msg' => 'Email não informado.']);
            return;
        }
        
        if (empty($this->getCodigo_usuario())) {
            echo json_encode(['codigo' => 4, 'msg' => 'Código do Usuario não informado.']);
            return;
            }
        

        $this->load->model('M_Usuario');
        $retorno = $this->M_Usuario->alterarUsuario(
            $this->getNome(), $this->getSenha(), $this->getEmail(), $this->getCodigo_usuario());
    
        echo json_encode($retorno);
    }
    
            
    public function apagarUsuario(){
        $json = file_get_contents('php://input');
        $resultado = json_decode($json);
    
        $lista = array("codigo_usuario" => '0');

        if (verificarParam($resultado, $lista) == 1){
            $this->setCodigo_usuario($resultado->codigo_usuario);
    
    
        if(strlen($this->getCodigo_usuario()) == 0){
            $retorno = array('codigo' => 3,
                             'msg'    => 'Código do usuário nao informado.');
        }else{
            $this->load->model('M_Usuario');
    
            $retorno = $this->M_Usuario->apagarUsuario($this->getCodigo_usuario());
        }
    
        echo json_encode($retorno);
        }
    }

    public function vincularUsuarioToken(){

        $json = file_get_contents('php://input');
        $resultado = json_decode($json);

        $lista = array('codigo_usuario' => '0',
                       'numero_token'   => '0');

        if (verificarParam($resultado, $lista) == 1){

            $this->setCodigo_usuario($resultado->codigo_usuario);
            $this->setNumero_Token($resultado->numero_token);

        if(strlen($this->getCodigo_usuario()) ==0){
            $retorno = array('codigo'=> 3,
                             'msg'=> 'Codigo do token não informado');

        }elseif(strlen($this->getNumero_Token()) == 0){
            $retorno = array('codigo'=> 3,
                             'msg'=> 'Numero do token não informado');

        }else{
            $this->load->model('M_Usuario');

            $retorno = $this->M_Usuario->vincularUsuarioToken($this->getCodigo_usuario(),
                       $this->getNumero_Token());
        }
        }else{
            $retorno = array('codigo'=> 99,
            'msg'=> 'Os campos do FrontEnd não representam o metodo de consulta, verifique');
        }

        echo json_encode($retorno);
    }
}

